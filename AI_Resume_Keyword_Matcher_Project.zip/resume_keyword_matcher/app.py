"""
AI Resume Keyword Matcher - Flask web application.

Upload (PDF / DOCX / TXT) or paste a resume, paste a job description, and get:
match score, matched and missing keywords, section checks and improvement tips.
Past analyses are kept in a local SQLite history (only results are stored,
never the full resume text).
"""
import csv
import io
import json
import os
import secrets
import sqlite3
from datetime import datetime

from flask import (Flask, Response, abort, flash, g, redirect, render_template,
                   request, session, url_for)

from matcher import analyse

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
ALLOWED_EXT = {".pdf", ".docx", ".txt"}
MIN_CHARS = 80

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["DATABASE"] = os.path.join(BASE_DIR, "matcher.db")
app.config["MAX_CONTENT_LENGTH"] = 3 * 1024 * 1024  # 3 MB upload limit

SCHEMA = """
CREATE TABLE IF NOT EXISTS analyses (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    job_title  TEXT NOT NULL,
    source     TEXT NOT NULL,           -- file name or 'Pasted text'
    score      INTEGER NOT NULL,
    result     TEXT NOT NULL,           -- JSON of analysis output
    created_at TEXT NOT NULL
);
"""


# ------------------------------------------------------------------ database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    get_db().executescript(SCHEMA)
    get_db().commit()


# ------------------------------------------------------------------ security
@app.before_request
def csrf_protect():
    if request.method == "POST":
        token = session.get("_csrf")
        if not token or not secrets.compare_digest(token, request.form.get("_csrf", "")):
            abort(400, "Invalid or missing CSRF token. Refresh the page and try again.")


@app.context_processor
def inject_globals():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_hex(16)
    return {"csrf_token": session["_csrf"]}


@app.errorhandler(413)
def too_large(_e):
    return render_template("error.html", code=413, message="File is too large (max 3 MB)."), 413


@app.errorhandler(404)
def not_found(_e):
    return render_template("error.html", code=404, message="Page not found."), 404


@app.errorhandler(400)
def bad_request(e):
    return render_template("error.html", code=400, message=getattr(e, "description", "Bad request.")), 400


# ------------------------------------------------------------ file reading
def extract_text(file_storage):
    """Return (text, error) from an uploaded PDF / DOCX / TXT file."""
    name = file_storage.filename or ""
    ext = os.path.splitext(name)[1].lower()
    if ext not in ALLOWED_EXT:
        return "", "Unsupported file type. Please upload a PDF, DOCX or TXT file."
    data = file_storage.read()
    try:
        if ext == ".txt":
            return data.decode("utf-8", errors="ignore"), None
        if ext == ".docx":
            from docx import Document
            doc = Document(io.BytesIO(data))
            parts = [p.text for p in doc.paragraphs]
            for table in doc.tables:
                for row in table.rows:
                    parts.extend(c.text for c in row.cells)
            return "\n".join(parts), None
        if ext == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            return "\n".join((pg.extract_text() or "") for pg in reader.pages), None
    except Exception:
        return "", "Could not read that file. Try another file or paste the text instead."
    return "", "Unsupported file."


# ------------------------------------------------------------------ routes
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/analyze", methods=["POST"])
def analyze_route():
    job_title = request.form.get("job_title", "").strip()[:80] or "Untitled job"
    jd = request.form.get("job_description", "").strip()
    resume_text = request.form.get("resume_text", "").strip()
    source = "Pasted text"

    upload = request.files.get("resume_file")
    if upload and upload.filename:
        text, err = extract_text(upload)
        if err:
            flash(err, "error")
            return redirect(url_for("index"))
        resume_text, source = text, os.path.basename(upload.filename)[:80]
        if len(resume_text.strip()) < MIN_CHARS:
            flash("Very little text could be read from the file (scanned PDFs are not supported). "
                  "Please paste your resume text instead.", "error")
            return redirect(url_for("index"))

    if len(resume_text) < MIN_CHARS:
        flash("Please upload or paste your resume (at least a few lines).", "error")
        return redirect(url_for("index"))
    if len(jd) < MIN_CHARS:
        flash("Please paste the job description (at least a few lines).", "error")
        return redirect(url_for("index"))

    result = analyse(resume_text[:60000], jd[:30000])
    db = get_db()
    cur = db.execute(
        "INSERT INTO analyses (job_title, source, score, result, created_at) VALUES (?, ?, ?, ?, ?)",
        (job_title, source, result["score"], json.dumps(result), datetime.now().strftime("%Y-%m-%d %H:%M")))
    db.commit()
    return redirect(url_for("result", analysis_id=cur.lastrowid))


def load_analysis(analysis_id):
    row = get_db().execute("SELECT * FROM analyses WHERE id = ?", (analysis_id,)).fetchone()
    if row is None:
        abort(404)
    return row, json.loads(row["result"])


@app.route("/result/<int:analysis_id>")
def result(analysis_id):
    row, data = load_analysis(analysis_id)
    return render_template("result.html", row=row, r=data)


@app.route("/history")
def history():
    rows = get_db().execute("SELECT id, job_title, source, score, created_at FROM analyses "
                            "ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("history.html", rows=rows)


@app.route("/delete/<int:analysis_id>", methods=["POST"])
def delete(analysis_id):
    db = get_db()
    cur = db.execute("DELETE FROM analyses WHERE id = ?", (analysis_id,))
    db.commit()
    if cur.rowcount == 0:
        abort(404)
    flash("Analysis deleted.", "info")
    return redirect(url_for("history"))


@app.route("/export/<int:analysis_id>.csv")
def export_csv(analysis_id):
    row, r = load_analysis(analysis_id)
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Job title", row["job_title"]])
    w.writerow(["Score", r["score"]])
    w.writerow(["Grade", r["grade"]])
    w.writerow([])
    w.writerow(["Keyword", "Type", "Status"])
    for k in r["matched"]:
        w.writerow([k["term"], k["kind"], "Matched"])
    for k in r["missing"]:
        w.writerow([k["term"], k["kind"], "Missing"])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename=match_{analysis_id}.csv"})


with app.app_context():
    init_db()

if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG") == "1")
