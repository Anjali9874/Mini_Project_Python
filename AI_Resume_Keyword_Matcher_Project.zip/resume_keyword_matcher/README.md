# AI Resume Keyword Matcher

A Flask web app that compares a resume with a job description and shows a match score,
matched / missing keywords, section checks and improvement tips.

## How it works
Tokenising + stop-word removal + stemming, a 150+ skill dictionary with aliases,
keyword extraction from the job description, and TF-IDF cosine similarity.
Score = 60% keyword coverage + 25% text similarity + 15% resume sections.

## Run it (Windows: open a terminal INSIDE this folder first)
```bash
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Run the tests
```bash
python -m unittest -v
```

## Files
- `app.py` – Flask routes, file upload, database, security
- `matcher.py` – the NLP engine
- `templates/`, `static/` – pages and styling

Privacy: resume text is never saved; only the results are kept in History.
