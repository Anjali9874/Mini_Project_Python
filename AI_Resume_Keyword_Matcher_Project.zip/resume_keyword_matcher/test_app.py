"""Automated tests. Run:  python -m unittest -v"""
import io
import os
import re
import tempfile
import unittest

import app as tracker
from matcher import analyse, find_skills, extract_jd_keywords, stem

GOOD_RESUME = """
Rahul Sharma | rahul@example.com | +91 9876543210 | github.com/rahul
Education: B.Tech Computer Science, ABC University, CGPA 8.4
Technical Skills: Python, Flask, Django, SQL, MySQL, Git, HTML, CSS, JavaScript, REST API, Docker, Pandas
Projects: Built a Flask web application used by 200 students with MySQL database and REST API.
Developed machine learning model with scikit-learn and pandas improving accuracy by 15%.
Internship: Python developer intern - wrote unit testing using pytest and worked in Agile team.
Achievements: Certifications in Python and SQL. Strong communication and teamwork.
"""

JD = """
We are looking for a Python Developer Intern. Responsibilities include building web applications using Flask or Django,
designing REST API endpoints, writing SQL queries on MySQL or PostgreSQL, and version control with Git.
Knowledge of Docker, AWS and unit testing is a plus. The candidate must have strong communication skills and work in an Agile team.
Experience with machine learning and data analysis is preferred. Build scalable web applications.
"""

BAD_RESUME = """
Priya Verma. I enjoy painting, cooking and travelling to new places. I have worked as a shop assistant and cashier
handling customers and cash. Hobbies include dancing and music. I am hard working and punctual and love learning.
"""


class MatcherTests(unittest.TestCase):
    def test_skill_detection_and_aliases(self):
        s = find_skills("Used ReactJS, Node.js, C++ and C# with k8s; also Postgres and sklearn.")
        for expected in ("react", "node.js", "c++", "c#", "kubernetes", "postgresql", "scikit-learn"):
            self.assertIn(expected, s)

    def test_no_false_positive_substrings(self):
        s = find_skills("I enjoy javascripting? Not really. Scalability and javelin throwing.")
        self.assertNotIn("java", s)
        self.assertNotIn("scala", s)

    def test_stemmer(self):
        self.assertEqual(stem("applications"), stem("application"))
        self.assertEqual(stem("developing"), stem("developed"))

    def test_jd_keywords_include_skills(self):
        terms = {k["term"] for k in extract_jd_keywords(JD)}
        for t in ("python", "flask", "django", "sql", "docker", "aws", "git"):
            self.assertIn(t, terms)

    def test_good_resume_scores_high_and_finds_missing(self):
        r = analyse(GOOD_RESUME, JD)
        self.assertGreaterEqual(r["score"], 65)
        missing = {k["term"] for k in r["missing"]}
        self.assertIn("aws", missing)             # not in resume
        matched = {k["term"] for k in r["matched"]}
        self.assertIn("flask", matched)
        self.assertTrue(all(r["sections"].values()))

    def test_bad_resume_scores_low(self):
        r = analyse(BAD_RESUME, JD)
        self.assertLess(r["score"], 35)
        self.assertEqual(r["grade"], "Low match")
        self.assertTrue(r["suggestions"])

    def test_good_beats_bad(self):
        self.assertGreater(analyse(GOOD_RESUME, JD)["score"], analyse(BAD_RESUME, JD)["score"] + 30)

    def test_score_bounds(self):
        for res in (GOOD_RESUME, BAD_RESUME, "x"):
            self.assertTrue(0 <= analyse(res, JD)["score"] <= 100)


class WebTests(unittest.TestCase):
    def setUp(self):
        self.fd, self.path = tempfile.mkstemp(suffix=".db")
        tracker.app.config.update(DATABASE=self.path, TESTING=True)
        with tracker.app.app_context():
            tracker.init_db()
        self.c = tracker.app.test_client()

    def tearDown(self):
        os.close(self.fd)
        os.unlink(self.path)

    def token(self):
        html = self.c.get("/").get_data(as_text=True)
        return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)

    def post(self, resume=GOOD_RESUME, jd=JD, file=None, title="Python Intern"):
        data = {"_csrf": self.token(), "job_title": title, "resume_text": resume, "job_description": jd}
        if file:
            data["resume_file"] = file
        return self.c.post("/analyze", data=data, content_type="multipart/form-data", follow_redirects=True)

    def test_pages_load(self):
        for url in ("/", "/history"):
            self.assertEqual(self.c.get(url).status_code, 200)
        self.assertEqual(self.c.get("/result/999").status_code, 404)

    def test_csrf_required(self):
        r = self.c.post("/analyze", data={"job_description": JD, "resume_text": GOOD_RESUME})
        self.assertEqual(r.status_code, 400)

    def test_full_flow_and_history(self):
        r = self.post()
        page = r.get_data(as_text=True)
        self.assertIn("Matched keywords", page)
        self.assertIn("Missing keywords", page)
        self.assertIn("Python Intern", page)
        self.assertIn("Python Intern", self.c.get("/history").get_data(as_text=True))

    def test_validation_messages(self):
        self.assertIn(b"upload or paste your resume", self.post(resume="short").data)
        self.assertIn(b"paste the job description", self.post(jd="short").data)

    def test_txt_upload(self):
        f = (io.BytesIO(GOOD_RESUME.encode()), "resume.txt")
        self.assertIn(b"resume.txt", self.post(resume="", file=f).data)

    def test_docx_upload(self):
        from docx import Document
        d = Document()
        for line in GOOD_RESUME.strip().splitlines():
            d.add_paragraph(line)
        buf = io.BytesIO(); d.save(buf); buf.seek(0)
        r = self.post(resume="", file=(buf, "cv.docx"))
        self.assertIn(b"cv.docx", r.data)
        self.assertIn(b"Matched keywords", r.data)

    def test_pdf_upload(self):
        # build a tiny real PDF containing text, using LibreOffice-free pure approach (reportlab absent) -> minimal PDF
        text = " ".join(GOOD_RESUME.split())[:300].replace("(", "").replace(")", "")
        stream = f"BT /F1 10 Tf 20 700 Td ({text}) Tj ET"
        objs = ["<< /Type /Catalog /Pages 2 0 R >>", "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
                "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
                f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream", "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>"]
        out, offs = b"%PDF-1.4\n", []
        for i, o in enumerate(objs, 1):
            offs.append(len(out)); out += f"{i} 0 obj\n{o}\nendobj\n".encode()
        xref = len(out)
        out += f"xref\n0 {len(objs)+1}\n0000000000 65535 f \n".encode()
        for o in offs:
            out += f"{o:010d} 00000 n \n".encode()
        out += f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode()
        r = self.post(resume="", file=(io.BytesIO(out), "cv.pdf"))
        self.assertIn(b"cv.pdf", r.data)

    def test_rejects_bad_file_type(self):
        r = self.post(resume="", file=(io.BytesIO(b"MZ..."), "virus.exe"))
        self.assertIn(b"Unsupported file type", r.data)

    def test_csv_export_and_delete(self):
        self.post()
        r = self.c.get("/export/1.csv")
        self.assertEqual(r.mimetype, "text/csv")
        self.assertIn(b"Matched", r.data)
        r = self.c.post("/delete/1", data={"_csrf": self.token()}, follow_redirects=True)
        self.assertIn(b"Analysis deleted", r.data)
        self.assertEqual(self.c.get("/result/1").status_code, 404)

    def test_html_escaped(self):
        r = self.post(title="<script>alert(1)</script>")
        self.assertNotIn(b"<script>alert(1)</script>", r.data)

    def test_resume_text_not_stored(self):
        self.post(resume=GOOD_RESUME + " UNIQUEMARKER123")
        with tracker.app.app_context():
            rows = tracker.get_db().execute("SELECT * FROM analyses").fetchall()
            self.assertNotIn("UNIQUEMARKER123", " ".join(str(tuple(r)) for r in rows))


if __name__ == "__main__":
    unittest.main()
