"""
Core NLP engine of the Resume Keyword Matcher (pure Python, no heavy ML libraries).

Pipeline
--------
1. Clean + tokenise text, remove stop-words, apply light stemming.
2. Detect known skills / phrases from a built-in skill dictionary (with aliases).
3. Extract the most important remaining keywords from the job description
   using term-frequency weighting (unigrams + bigrams).
4. Compare with the resume -> matched / missing keywords.
5. Score = weighted keyword coverage (60 %) + TF-IDF cosine similarity (25 %)
   + section / formatting checks (15 %).
"""
import math
import re
from collections import Counter

# --------------------------------------------------------------------------
# Skill dictionary:  canonical name -> list of aliases (all lower-case)
# --------------------------------------------------------------------------
SKILLS = {
    # programming languages
    "python": ["python", "python3"], "java": ["java"], "javascript": ["javascript", "js", "ecmascript"],
    "typescript": ["typescript"], "c++": ["c++", "cpp"], "c#": ["c#", "csharp"], "c": ["c language"],
    "go": ["golang"], "rust": ["rust"], "php": ["php"], "ruby": ["ruby"], "kotlin": ["kotlin"],
    "swift": ["swift"], "r": ["r programming"], "matlab": ["matlab"], "scala": ["scala"],
    "bash": ["bash", "shell scripting"], "sql": ["sql", "structured query language"],
    # web
    "html": ["html", "html5"], "css": ["css", "css3"], "react": ["react", "reactjs", "react.js"],
    "angular": ["angular", "angularjs"], "vue": ["vue", "vuejs", "vue.js"], "node.js": ["node.js", "nodejs", "node"],
    "express": ["express", "expressjs"], "django": ["django"], "flask": ["flask"], "fastapi": ["fastapi"],
    "spring boot": ["spring boot", "springboot", "spring"], "bootstrap": ["bootstrap"],
    "tailwind": ["tailwind", "tailwindcss"], "rest api": ["rest api", "restful", "rest apis", "rest"],
    "graphql": ["graphql"], "jquery": ["jquery"],
    # data / ml
    "machine learning": ["machine learning", "ml"], "deep learning": ["deep learning"],
    "nlp": ["nlp", "natural language processing"], "computer vision": ["computer vision"],
    "data analysis": ["data analysis", "data analytics", "analytics"], "data science": ["data science"],
    "pandas": ["pandas"], "numpy": ["numpy"], "scikit-learn": ["scikit-learn", "sklearn", "scikit learn"],
    "tensorflow": ["tensorflow"], "pytorch": ["pytorch"], "keras": ["keras"], "opencv": ["opencv"],
    "power bi": ["power bi", "powerbi"], "tableau": ["tableau"], "excel": ["excel", "ms excel", "microsoft excel"],
    "statistics": ["statistics", "statistical"], "data visualization": ["data visualization", "data visualisation"],
    "matplotlib": ["matplotlib"], "spark": ["spark", "pyspark"], "hadoop": ["hadoop"],
    "etl": ["etl"], "data structures": ["data structures", "dsa"], "algorithms": ["algorithms", "algorithm"],
    # databases
    "mysql": ["mysql"], "postgresql": ["postgresql", "postgres"], "mongodb": ["mongodb", "mongo"],
    "sqlite": ["sqlite"], "oracle": ["oracle"], "redis": ["redis"], "firebase": ["firebase"],
    "nosql": ["nosql"], "dbms": ["dbms"],
    # cloud / devops
    "aws": ["aws", "amazon web services"], "azure": ["azure"], "gcp": ["gcp", "google cloud"],
    "docker": ["docker"], "kubernetes": ["kubernetes", "k8s"], "git": ["git"], "github": ["github"],
    "ci/cd": ["ci/cd", "cicd", "continuous integration"], "jenkins": ["jenkins"], "linux": ["linux", "unix"],
    "devops": ["devops"], "terraform": ["terraform"], "agile": ["agile", "scrum"], "jira": ["jira"],
    # testing / general tech
    "unit testing": ["unit testing", "unittest", "pytest", "junit"], "selenium": ["selenium"],
    "oop": ["oop", "object oriented", "object-oriented"], "api": ["api", "apis"],
    "microservices": ["microservices"], "networking": ["networking", "computer networks"],
    "cybersecurity": ["cybersecurity", "cyber security", "information security"],
    "android": ["android"], "ios": ["ios"], "flutter": ["flutter"], "figma": ["figma"],
    "ui/ux": ["ui/ux", "ux design", "ui design", "user experience"],
    # soft skills / business
    "communication": ["communication", "communicate"], "teamwork": ["teamwork", "team player", "collaboration", "collaborative"],
    "leadership": ["leadership", "led a team", "team lead"], "problem solving": ["problem solving", "problem-solving"],
    "time management": ["time management"], "critical thinking": ["critical thinking"],
    "project management": ["project management"], "presentation": ["presentation", "presentations"],
    "adaptability": ["adaptability", "adaptable"], "analytical": ["analytical", "analytical skills"],
}

ALIAS_TO_CANON = {}
for canon, aliases in SKILLS.items():
    ALIAS_TO_CANON[canon] = canon
    for a in aliases:
        ALIAS_TO_CANON[a] = canon

STOPWORDS = set("""
a about above after again against all also am an and any are as at be because been before being below between both
but by can could did do does doing down during each few for from further had has have having he her here hers him his
how i if in into is it its itself just me more most my no nor not now of off on once only or other our ours out over
own same she should so some such than that the their theirs them then there these they this those through to too
under until up very was we were what when where which while who whom why will with would you your yours
ability able across additional etc including include includes looking must need needed new plus preferred
required requirements requirement responsibilities responsible role roles strong team teams work working works
years year experience experienced candidate candidates company join opportunity good great excellent knowledge
skills skill understanding using use used within well will etc per via like want seeking ideal
building build builds built designing design develop developing developer looking ensure ensuring provide
providing support supporting responsibilities perform performing help helping make making create creating
""".split())

SECTION_PATTERNS = {
    "Contact info": r"(@[a-z0-9.-]+\.[a-z]{2,}|\+?\d[\d\s-]{8,}\d|linkedin\.com|github\.com)",
    "Education": r"\b(education|b\.?tech|b\.?e\.?|bca|mca|b\.?sc|m\.?sc|bachelor|master|degree|university|college|cgpa|gpa)\b",
    "Skills section": r"\b(skills|technical skills|core competencies|technologies)\b",
    "Projects": r"\b(projects?|academic projects?|personal projects?)\b",
    "Experience / Internship": r"\b(experience|internship|intern|work history|employment|training)\b",
    "Achievements": r"\b(achievements?|awards?|certifications?|certificates?|honou?rs|accomplishments)\b",
}

WORD_RE = re.compile(r"[a-z][a-z0-9+#./-]*[a-z0-9+#]|[a-z]")


def stem(word):
    """Very small suffix-stripping stemmer (enough for keyword comparison)."""
    for suf in ("ization", "ations", "ation", "ingly", "ings", "ing", "ies", "ied", "ers", "er", "ed", "es", "s"):
        if word.endswith(suf) and len(word) - len(suf) >= 3:
            if suf in ("ies", "ied"):
                return word[: -len(suf)] + "y"
            return word[: -len(suf)]
    return word


def normalise(text):
    text = text.lower().replace("’", "'")
    text = re.sub(r"[•●▪–—|•·]", " ", text)
    return text


def tokens(text):
    return [t.strip(".-/") for t in WORD_RE.findall(normalise(text)) if t.strip(".-/")]


def content_tokens(text):
    return [t for t in tokens(text) if t not in STOPWORDS and len(t) > 1]


# --------------------------------------------------------------------------
# Skill detection
# --------------------------------------------------------------------------
def _alias_regex(alias):
    return r"(?<![a-z0-9+#])" + re.escape(alias) + r"(?![a-z0-9+#])"


_ALIAS_PATTERNS = [(alias, canon, re.compile(_alias_regex(alias)))
                   for alias, canon in sorted(ALIAS_TO_CANON.items(), key=lambda x: -len(x[0]))]


def find_skills(text):
    """Return {canonical_skill: count} found in the text."""
    t = normalise(text)
    found = Counter()
    for alias, canon, pat in _ALIAS_PATTERNS:
        # ambiguous short aliases are matched only as whole words (handled by regex)
        n = len(pat.findall(t))
        if n:
            found[canon] += n
    return found


# --------------------------------------------------------------------------
# Keyword extraction from the job description
# --------------------------------------------------------------------------
def extract_jd_keywords(jd_text, top_n=25):
    """
    Returns list of dicts: {term, weight, kind}  (kind = 'skill' or 'keyword').
    Skills get a boost; other keywords are ranked by frequency (unigrams + bigrams).
    """
    skills = find_skills(jd_text)
    results = {}
    for skill, cnt in skills.items():
        results[skill] = {"term": skill, "weight": 3.0 + min(cnt, 4) * 0.5, "kind": "skill"}

    toks = [t for t in tokens(jd_text)]
    skill_words = set()
    for s in skills:
        skill_words.update(re.findall(r"[a-z0-9+#]+", s))

    # candidate unigrams
    uni = Counter()
    for t in toks:
        if t in STOPWORDS or len(t) < 3 or t.isdigit() or t in skill_words:
            continue
        uni[stem(t)] += 1
    display = {}
    for t in toks:
        display.setdefault(stem(t), t)

    # candidate bigrams (both words must be content words)
    bi = Counter()
    for a, b in zip(toks, toks[1:]):
        if a in STOPWORDS or b in STOPWORDS or len(a) < 3 or len(b) < 3:
            continue
        if a in skill_words or b in skill_words:
            continue
        bi[f"{a} {b}"] += 1

    for phrase, cnt in bi.items():
        if cnt >= 2:
            results.setdefault(phrase, {"term": phrase, "weight": 1.5 + cnt * 0.5, "kind": "keyword"})
    for st, cnt in uni.items():
        if cnt >= 2:
            term = display.get(st, st)
            if any(term in r for r in results if " " in r):
                continue  # already covered by a bigram
            results.setdefault(term, {"term": term, "weight": 1.0 + cnt * 0.4, "kind": "keyword"})

    ranked = sorted(results.values(), key=lambda d: (-d["weight"], d["term"]))
    return ranked[:top_n]


# --------------------------------------------------------------------------
# Matching + scoring
# --------------------------------------------------------------------------
def _present(term, kind, resume_text, resume_skills, resume_stems):
    if kind == "skill":
        return term in resume_skills
    parts = term.split()
    if len(parts) == 1:
        return stem(parts[0]) in resume_stems
    stemmed_resume = " ".join(stem(t) for t in tokens(resume_text))
    return " ".join(stem(p) for p in parts) in stemmed_resume


def tfidf_cosine(doc_a, doc_b):
    """Cosine similarity of TF-IDF vectors for two documents (idf from the 2-doc corpus)."""
    ta = Counter(stem(t) for t in content_tokens(doc_a))
    tb = Counter(stem(t) for t in content_tokens(doc_b))
    vocab = set(ta) | set(tb)
    if not vocab:
        return 0.0
    idf = {w: math.log((1 + 2) / (1 + (w in ta) + (w in tb))) + 1 for w in vocab}
    va = {w: (1 + math.log(c)) * idf[w] for w, c in ta.items()}
    vb = {w: (1 + math.log(c)) * idf[w] for w, c in tb.items()}
    dot = sum(va[w] * vb.get(w, 0) for w in va)
    na = math.sqrt(sum(v * v for v in va.values()))
    nb = math.sqrt(sum(v * v for v in vb.values()))
    return dot / (na * nb) if na and nb else 0.0


def check_sections(resume_text):
    t = normalise(resume_text)
    return {name: bool(re.search(pat, t)) for name, pat in SECTION_PATTERNS.items()}


def grade(score):
    if score >= 80:
        return "Excellent match"
    if score >= 65:
        return "Good match"
    if score >= 45:
        return "Fair match"
    return "Low match"


def analyse(resume_text, jd_text):
    """Main entry point. Returns a dict with everything the result page needs."""
    resume_skills = find_skills(resume_text)
    resume_stems = {stem(t) for t in tokens(resume_text)}

    jd_keywords = extract_jd_keywords(jd_text)
    matched, missing = [], []
    for kw in jd_keywords:
        (matched if _present(kw["term"], kw["kind"], resume_text, resume_skills, resume_stems)
         else missing).append(kw)

    total_w = sum(k["weight"] for k in jd_keywords)
    coverage = (sum(k["weight"] for k in matched) / total_w) if total_w else 0.0
    cosine = tfidf_cosine(resume_text, jd_text)
    sections = check_sections(resume_text)
    section_score = sum(sections.values()) / len(sections)

    score = round(100 * (0.60 * coverage + 0.25 * min(cosine * 1.6, 1.0) + 0.15 * section_score))
    score = max(0, min(100, score))

    jd_skill_set = {k["term"] for k in jd_keywords if k["kind"] == "skill"}
    extra_skills = sorted(s for s in resume_skills if s not in jd_skill_set)

    suggestions = []
    miss_skills = [m["term"] for m in missing if m["kind"] == "skill"]
    miss_words = [m["term"] for m in missing if m["kind"] == "keyword"]
    if miss_skills:
        suggestions.append("Add these skills to your Skills section or project descriptions if you genuinely have them: "
                           + ", ".join(miss_skills[:8]) + ".")
    if miss_words:
        suggestions.append("Use the job description's own wording where it is true for you: "
                           + ", ".join(miss_words[:6]) + ".")
    for name, ok in sections.items():
        if not ok:
            suggestions.append(f"Your resume seems to be missing a clear “{name}” section.")
    wc = len(tokens(resume_text))
    if wc < 150:
        suggestions.append("Your resume looks very short (under 150 words). Add more detail about projects and results.")
    elif wc > 1000:
        suggestions.append("Your resume is long (over 1000 words). Aim for one page for a fresher.")
    if not re.search(r"\b\d+\s*(%|percent|users|projects|students|x)\b", normalise(resume_text)):
        suggestions.append("Add measurable results (numbers, percentages) to your project or experience bullets.")
    if score >= 80 and not suggestions:
        suggestions.append("Great job! Your resume already covers the key requirements.")

    return {
        "score": score, "grade": grade(score),
        "coverage": round(coverage * 100), "similarity": round(min(cosine, 1.0) * 100),
        "section_score": round(section_score * 100),
        "matched": matched, "missing": missing, "extra_skills": extra_skills,
        "sections": sections, "suggestions": suggestions,
        "resume_words": wc, "jd_keyword_count": len(jd_keywords),
    }
